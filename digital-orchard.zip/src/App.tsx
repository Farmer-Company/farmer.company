/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/Home/HeroSection';
import { SocialProofSection } from './components/Home/SocialProofSection';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LanguageProvider } from './lib/LanguageContext';
import { AuthProvider } from './lib/AuthContext';
import { MarketPage } from './components/Pages/Market';
import { PricesPage } from './components/Pages/Prices';
import { InsightsPage } from './components/Pages/Insights';
import { ConfigurePage } from './components/Pages/Configure';
import { AuthFlow } from './components/AuthFlow';
import { LanguagePopup } from './components/LanguagePopup';
import { LoadingScreen } from './components/LoadingScreen';
import { NotFound } from './pages/NotFound';
import { AnimatePresence } from 'framer-motion';

const HomePage = () => (
<main>
  <HeroSection />
  <SocialProofSection />
</main>
);

export default function App() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    // Simulate initial sequence
    const timer = setTimeout(() => setLoading(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <Router>
      <LanguageProvider>
        <AuthProvider>
          <AnimatePresence>
            {loading && <LoadingScreen key="loading" />}
          </AnimatePresence>
          
          <div className="min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground relative">
            <ErrorBoundary>
              <Navbar />
              <LanguagePopup />
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/market" element={<MarketPage />} />
                <Route path="/prices" element={<PricesPage />} />
                <Route path="/insights" element={<InsightsPage />} />
                <Route path="/configure" element={<ConfigurePage />} />
                <Route path="/signin" element={<AuthFlow />} />
                <Route path="/get-started" element={<AuthFlow />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
              
            <footer className="py-12 px-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8 bg-[#050505]">
              <div className="flex items-center gap-3">
                <div className="logo text-white font-black text-sm tracking-tighter uppercase">
                  DIGITAL<span className="text-primary"> ORCHARD</span>
                </div>
              </div>
                
                <div className="flex gap-8 mono text-[9px] text-foreground/30 uppercase tracking-[0.2em]">
                  <a href="#" className="hover:text-primary transition-colors">Privacy</a>
                  <a href="#" className="hover:text-primary transition-colors">Terms</a>
                  <a href="#" className="hover:text-primary transition-colors">Contact</a>
                </div>
                
                <p className="mono text-[9px] text-foreground/20 uppercase tracking-widest">
                  © 2026 DIGITAL ORCHARD • TAMIL NADU, INDIA
                </p>
              </footer>
            </ErrorBoundary>
          </div>
        </AuthProvider>
      </LanguageProvider>
    </Router>
  );
}


