export interface MarketData {
  id: number;
  state: string;
  district: string;
  name: string;
  arrivals: number;
  commodities: number;
  tier: string;
}

export const markets: MarketData[] = [
  { id: 0, state: "Maharashtra", district: "Mumbai", name: "Mumbai", arrivals: 270019, commodities: 103, tier: "Regional Hub" },
  { id: 1, state: "Maharashtra", district: "Pune", name: "Pune", arrivals: 251866, commodities: 97, tier: "Regional Hub" },
  { id: 2, state: "NCT of Delhi", district: "Delhi", name: "Azadpur", arrivals: 242625, commodities: 89, tier: "Regional Hub" },
  { id: 3, state: "Karnataka", district: "Bangalore", name: "Binny Mill (F&V), Bangalore", arrivals: 220077, commodities: 53, tier: "Regional Hub" },
  { id: 4, state: "Karnataka", district: "Mysore", name: "Mysore (Bandipalya)", arrivals: 214398, commodities: 103, tier: "Regional Hub" },
  { id: 5, state: "Karnataka", district: "Bangalore", name: "Bangalore", arrivals: 194363, commodities: 59, tier: "Regional Hub" },
  { id: 6, state: "Kerala", district: "Palakad", name: "Palakkad", arrivals: 176398, commodities: 54, tier: "Regional Hub" },
  { id: 7, state: "Gujarat", district: "Vadodara(Baroda)", name: "Vadodara(Sayajipura)", arrivals: 172140, commodities: 49, tier: "Regional Hub" },
  { id: 8, state: "Kerala", district: "Malappuram", name: "Manjeri", arrivals: 168640, commodities: 73, tier: "Regional Hub" },
  { id: 9, state: "Uttar Pradesh", district: "Ayodhya", name: "Faizabad", arrivals: 166202, commodities: 98, tier: "Regional Hub" },
  { id: 10, state: "Uttar Pradesh", district: "Lucknow", name: "Lucknow", arrivals: 164876, commodities: 77, tier: "Regional Hub" },
  { id: 11, state: "Haryana", district: "Ambala", name: "Naraingarh", arrivals: 158399, commodities: 80, tier: "Regional Hub" },
  { id: 12, state: "Gujarat", district: "Ahmedabad", name: "Ahmedabad", arrivals: 156570, commodities: 68, tier: "Regional Hub" },
  { id: 13, state: "Kerala", district: "Idukki", name: "Thodupuzha", arrivals: 156412, commodities: 56, tier: "Regional Hub" },
  { id: 14, state: "Maharashtra", district: "Chattrapati Sambhajinagar", name: "Chattrapati Sambhajinagar", arrivals: 150466, commodities: 88, tier: "Regional Hub" },
  { id: 15, state: "Himachal Pradesh", district: "Kangra", name: "Kangra", arrivals: 148735, commodities: 62, tier: "Regional Hub" },
  { id: 16, state: "Uttar Pradesh", district: "Aligarh", name: "Aligarh", arrivals: 148097, commodities: 67, tier: "Regional Hub" },
  { id: 17, state: "Jammu and Kashmir", district: "Jammu", name: "Narwal Jammu (F&V)", arrivals: 147879, commodities: 91, tier: "Regional Hub" },
  { id: 18, state: "Gujarat", district: "Surat", name: "Surat", arrivals: 147477, commodities: 51, tier: "Regional Hub" },
  { id: 19, state: "Haryana", district: "Fatehabad", name: "Fatehabad", arrivals: 146482, commodities: 98, tier: "Regional Hub" },
  { id: 20, state: "Maharashtra", district: "Nagpur", name: "Nagpur", arrivals: 144725, commodities: 78, tier: "Regional Hub" },
  { id: 21, state: "Uttar Pradesh", district: "Muzaffarnagar", name: "Muzzafarnagar", arrivals: 144148, commodities: 67, tier: "Regional Hub" },
  { id: 22, state: "Maharashtra", district: "Sholapur", name: "Solapur", arrivals: 143409, commodities: 64, tier: "Regional Hub" },
  { id: 23, state: "Kerala", district: "Kollam", name: "Kollam", arrivals: 143279, commodities: 105, tier: "Regional Hub" },
  { id: 24, state: "Haryana", district: "Kurukshetra", name: "Shahabad", arrivals: 138838, commodities: 85, tier: "Regional Hub" },
  { id: 25, state: "Kerala", district: "Alappuzha", name: "Alappuzha", arrivals: 133945, commodities: 90, tier: "Regional Hub" },
  { id: 26, state: "Uttar Pradesh", district: "Gorakhpur", name: "Gorakhpur", arrivals: 133810, commodities: 69, tier: "Regional Hub" },
  { id: 27, state: "Uttar Pradesh", district: "Unnao", name: "Unnao", arrivals: 130057, commodities: 73, tier: "Regional Hub" },
  { id: 28, state: "Uttar Pradesh", district: "Ghaziabad", name: "Ghaziabad", arrivals: 128574, commodities: 63, tier: "Regional Hub" },
  { id: 29, state: "Rajasthan", district: "Ajmer", name: "Ajmer(F&V)", arrivals: 128072, commodities: 67, tier: "Regional Hub" },
  { id: 30, state: "Karnataka", district: "Shimoga", name: "Shimoga", arrivals: 127748, commodities: 97, tier: "Regional Hub" },
  { id: 31, state: "Uttar Pradesh", district: "Agra", name: "Agra", arrivals: 126924, commodities: 82, tier: "Regional Hub" },
  { id: 32, state: "Maharashtra", district: "Jalgaon", name: "Jalgaon", arrivals: 126877, commodities: 77, tier: "Regional Hub" },
  { id: 33, state: "Uttar Pradesh", district: "Bareilly", name: "Bareilly", arrivals: 126784, commodities: 64, tier: "Regional Hub" },
  { id: 34, state: "Gujarat", district: "Dahod", name: "Dahod", arrivals: 125692, commodities: 60, tier: "Regional Hub" },
  { id: 35, state: "Gujarat", district: "Vadodara(Baroda)", name: "Vadodara", arrivals: 125333, commodities: 100, tier: "Regional Hub" },
  { id: 36, state: "Gujarat", district: "Dahod", name: "Dahod(Veg. Market)", arrivals: 125202, commodities: 41, tier: "Regional Hub" },
  { id: 37, state: "Uttar Pradesh", district: "Saharanpur", name: "Saharanpur", arrivals: 125187, commodities: 75, tier: "Regional Hub" },
  { id: 38, state: "Uttar Pradesh", district: "Amethi", name: "Sultanpur", arrivals: 125086, commodities: 107, tier: "Regional Hub" },
  { id: 39, state: "Himachal Pradesh", district: "Kullu", name: "Bhuntar", arrivals: 124501, commodities: 63, tier: "Regional Hub" },
  { id: 6932, state: "Tamil Nadu", district: "Chengalpattu", name: "Keelkattalai(Uzhavar Sandhai )", arrivals: 111, commodities: 1, tier: "Local Mandi" },
  { id: 6933, state: "Tamil Nadu", district: "Vellore", name: "Thimiri APMC", arrivals: 111, commodities: 1, tier: "Local Mandi" },
  { id: 6934, state: "Tamil Nadu", district: "Erode", name: "Elumathur APMC", arrivals: 111, commodities: 1, tier: "Local Mandi" },
  { id: 6943, state: "Bihar", district: "Rohtas", name: "Nokha APMC", arrivals: 11, commodities: 1, tier: "Local Mandi" }
];
