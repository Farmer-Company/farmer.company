import React from 'react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/src/lib/LanguageContext';
import { Link, useNavigate, useLocation } from 'react-router-dom';

const NAV_ITEMS = [
  { label: 'ecosystem', path: '/' },
  { label: 'market', path: '/market' },
  { label: 'prices', path: '/prices' },
  { label: 'insights', path: '/insights' },
  { label: 'configure', path: '/configure' },
];

export const Navbar = () => {
  const { t, language, setLanguage } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <nav className="fixed top-0 left-0 z-[110] w-full px-12 py-8 flex flex-row justify-between items-center transition-all duration-300 pointer-events-none">
      {/* Left - Logo */}
      <div className="flex-1 flex justify-start">
        <Link to="/" className="logo text-white font-black text-2xl tracking-tighter uppercase focus:outline-none flex items-center gap-1 group pointer-events-auto">
          <span className="bg-primary text-black px-1.5 leading-none py-0.5">DIGITAL</span>
          <span className="text-white group-hover:text-primary transition-colors">ORCHARD</span>
        </Link>
      </div>

      {/* Center - Navigation Links */}
      <div className="flex items-center gap-1 pointer-events-auto bg-black/40 backdrop-blur-2xl px-2 py-1.5 rounded-full border border-white/10 shadow-xl">
        {NAV_ITEMS.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link 
              key={item.path}
              to={item.path}
              className={`px-4 py-2 rounded-full mono text-[10px] font-black uppercase tracking-[0.15em] transition-all duration-300 relative group ${
                isActive 
                  ? 'text-primary' 
                  : 'text-white/40 hover:text-white'
              }`}
            >
              {t(item.label)}
              {isActive && (
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary shadow-[0_0_8px_var(--primary)]" />
              )}
            </Link>
          );
        })}
      </div>

      {/* Right - CTA & Lang */}
      <div className="flex-1 flex justify-end">
        <div className="flex items-center gap-6 pointer-events-auto bg-black/20 backdrop-blur-md px-6 py-2 rounded-full border border-white/5 shadow-lg">
          <select 
            value={language} 
            onChange={(e) => setLanguage(e.target.value as any)}
            className="bg-transparent border-none text-[10px] font-bold text-foreground-muted uppercase tracking-[2px] outline-none cursor-pointer hover:text-white"
          >
            <option value="en" className="bg-[#050505]">EN</option>
            <option value="hi" className="bg-[#050505]">हिन्दी</option>
            <option value="ta" className="bg-[#050505]">தமிழ்</option>
            <option value="kn" className="bg-[#050505]">ಕನ್ನಡ</option>
            <option value="te" className="bg-[#050505]">తెలుగు</option>
            <option value="mr" className="bg-[#050505]">मराठी</option>
            <option value="bn" className="bg-[#050505]">বাংলা</option>
          </select>
          
          <div className="w-px h-4 bg-white/10" />

          <button 
            onClick={() => navigate('/signin')}
            className="text-[11px] font-bold text-white uppercase tracking-[2px] hover:text-primary transition-colors cursor-pointer"
          >
            {t('signIn')}
          </button>
          <Button 
            variant="outline" 
            size="sm" 
            className="px-6 border-white/20 h-9 rounded-full hover:border-primary text-[10px] uppercase font-black tracking-widest"
            onClick={() => navigate('/get-started')}
          >
            {t('getStarted')}
          </Button>
        </div>
      </div>
    </nav>
  );
};

