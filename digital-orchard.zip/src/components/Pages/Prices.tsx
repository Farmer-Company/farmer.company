import React, { useState } from 'react';
import { useLanguage } from '@/src/lib/LanguageContext';
import { commodities, Commodity } from '@/src/data/commodities';

export const PricesPage = () => {
  const { t } = useLanguage();
  const [filter, setFilter] = useState('');

  const filtered = commodities.filter(c => 
    c.name.toLowerCase().includes(filter.toLowerCase()) ||
    c.code.includes(filter)
  );

  return (
    <div className="pt-32 px-10 min-h-screen bg-background text-white pb-24">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-16">
          <div className="space-y-4">
            <h1 className="display text-6xl font-black uppercase tracking-tighter">
              {t('prices')}<span className="text-primary">.</span>
            </h1>
            <p className="text-foreground-muted uppercase tracking-[3px] text-sm">Real-time Commodity Arbitration Feed</p>
          </div>

          <div className="w-full md:w-96">
            <input 
              type="text" 
              placeholder="Search Commodities or Codes..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="w-full bg-[#0D0D0D] border border-white/10 h-14 px-6 focus:border-primary outline-none mono text-xs uppercase tracking-widest"
            />
          </div>
        </div>
        
        <div className="mt-12 overflow-x-auto overflow-hidden border border-white/5 bg-[#080808]">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10 bg-[#0D0D0D]">
                <th className="py-6 px-8 text-[10px] font-black text-foreground-muted uppercase tracking-[3px]">Code</th>
                <th className="py-6 px-8 text-[10px] font-black text-foreground-muted uppercase tracking-[3px]">Commodity</th>
                <th className="py-6 px-8 text-[10px] font-black text-foreground-muted uppercase tracking-[3px]">Modal Price</th>
                <th className="py-6 px-8 text-[10px] font-black text-foreground-muted uppercase tracking-[3px]">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((item, i) => (
                <tr key={`${item.code}-${i}`} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors group">
                  <td className="py-8 px-8 mono text-xs text-foreground-muted uppercase tracking-widest leading-none">
                    #{item.code.padStart(3, '0')}
                  </td>
                  <td className="py-8 px-8 font-black text-xl uppercase tracking-tighter group-hover:text-primary transition-colors">
                    {item.name}
                  </td>
                  <td className="py-8 px-8 mono text-2xl font-black text-white/90">
                    ₹{(15 + (parseInt(item.code) % 50) + (i % 10)).toFixed(2)}
                  </td>
                  <td className="py-8 px-8">
                    <button className="text-[10px] font-black uppercase tracking-[2px] text-primary hover:text-white transition-colors">
                      Historical Feed →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="py-20 text-center text-foreground-muted uppercase mono text-xs tracking-widest">
              No matching commodities found in registry.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

