import React, { useState, useEffect } from 'react';
import { useLanguage } from '@/src/lib/LanguageContext';
import { marketplaceService } from '@/src/lib/os-services';
import { Listing } from '@/src/lib/os-types';
import { Truck, ShoppingCart, Loader2 } from 'lucide-react';
import { useAuth } from '@/src/lib/AuthContext';

export const MarketPage = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [filter, setFilter] = useState('');
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = marketplaceService.getActiveListings((data) => {
      setListings(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const filteredListings = listings.filter(l => 
    l.skuId.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="pt-32 px-10 min-h-screen bg-background text-white pb-24">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-16">
          <div className="space-y-4">
            <h1 className="display text-6xl font-black uppercase tracking-tighter">
              {t('market')}<span className="text-primary">.</span>
            </h1>
            <p className="text-foreground-muted uppercase tracking-[3px] text-sm">Industrial Procurement & Logistics Protocol</p>
          </div>
          
          <div className="w-full md:w-96">
            <input 
              type="text" 
              placeholder="Search by Commodity SKU..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="w-full bg-[#0D0D0D] border border-white/10 h-14 px-6 focus:border-primary outline-none mono text-xs uppercase tracking-widest"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-black text-white/40 uppercase tracking-[4px]">Verified Active Units</span>
              <span className="mono text-[10px] text-primary">{filteredListings.length} Nodes Online</span>
            </div>
            
            {loading ? (
              <div className="flex flex-col items-center justify-center py-20 bg-[#0D0D0D] border border-white/5 border-dashed">
                <Loader2 className="w-8 h-8 text-primary animate-spin mb-4" />
                <span className="mono text-[10px] uppercase tracking-widest text-white/20">Querying Global Inventory Ledger...</span>
              </div>
            ) : filteredListings.length === 0 ? (
              <div className="py-20 text-center bg-[#0D0D0D] border border-white/5 border-dashed">
                <span className="mono text-xs uppercase tracking-widest text-white/20">No matching procurement nodes found.</span>
              </div>
            ) : filteredListings.map((listing) => (
              <div key={listing.id} className="bg-[#0D0D0D] border border-white/5 p-8 group hover:border-primary/50 transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 h-full w-1 bg-white/5 group-hover:bg-primary transition-colors" />
                
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="bg-white/5 text-white/60 px-2 py-0.5 text-[9px] font-black uppercase tracking-widest">Active</span>
                    <div className="w-1 h-1 rounded-full bg-white/20" />
                    <span className="text-[10px] font-bold text-foreground-muted uppercase tracking-[2px]">Farmer ID: {listing.farmerId.slice(-6)}</span>
                  </div>
                  <h3 className="display text-3xl font-black uppercase tracking-tighter group-hover:text-primary transition-colors leading-none">{listing.skuId}</h3>
                  <div className="flex gap-6 mono text-[10px] text-foreground-muted uppercase tracking-widest pt-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green animate-pulse" />
                      <span>Volume: {listing.quantity_tonnes} MT</span>
                    </div>
                    <span>Expiry: {new Date(listing.expiry_date).toLocaleDateString()}</span>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 shrink-0">
                  <div className="hidden sm:flex flex-col items-end mr-4">
                    <span className="text-[9px] font-black text-primary uppercase tracking-widest mb-1">Procurement Alpha</span>
                    <span className="mono text-lg font-black tracking-tight text-white/80">₹{listing.asking_price.toLocaleString()} <small className="text-[10px] opacity-40">/T</small></span>
                  </div>
                  <button className="h-14 w-14 flex items-center justify-center border border-white/10 hover:border-primary group/icon bg-white/5 transition-all hover:scale-105 active:scale-95">
                    <ShoppingCart size={18} className="group-hover/icon:text-primary transition-colors" />
                  </button>
                  <button 
                    onClick={() => {
                      if (!user) return alert("Sign in to Settle Trades");
                      marketplaceService.createOrder({
                        listingId: listing.id,
                        buyerId: user.uid,
                        sellerId: listing.farmerId,
                        price_per_kg: listing.asking_price / 1000,
                        quantity_tonnes: listing.quantity_tonnes,
                        total_value: listing.asking_price * listing.quantity_tonnes,
                        status: 'pending',
                        paymentStatus: 'pending'
                      }).then(() => alert("Order Initiated on Digital Orchard Protocol"));
                    }}
                    className="h-14 bg-white text-black px-8 text-[11px] font-black uppercase tracking-[3px] hover:bg-primary transition-all hover:translate-x-1 active:translate-x-0"
                  >
                    Settle
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Logistics & Ops Sidebar */}
          <div className="space-y-8 lg:sticky lg:top-32 h-fit">
            <div className="bg-primary p-10 text-black shadow-[0_30px_60px_rgba(0,240,255,0.15)] relative overflow-hidden group">
              <div className="absolute top-[-20%] right-[-10%] opacity-10 group-hover:scale-110 transition-transform duration-700">
                <Truck size={240} />
              </div>
              <h4 className="text-2xl font-black uppercase tracking-tighter mb-4 relative z-10">Direct Fleet Integration</h4>
              <p className="text-sm font-bold leading-relaxed mb-8 opacity-80 relative z-10">
                Authorized AGRI Operating System vehicles available for immediate dispatch. Zero-middlemen cold chain logistics.
              </p>
              <button className="w-full py-5 bg-black text-white font-black uppercase tracking-[4px] text-[11px] hover:bg-white hover:text-black transition-all relative z-10">
                Open Dispatch Console
              </button>
            </div>

            <div className="border border-white/10 bg-[#0A0A0A] p-10 space-y-8 h-fit">
              <div className="space-y-2">
                <h4 className="text-lg font-black uppercase tracking-tighter text-white">System Arbitration</h4>
                <div className="w-12 h-1 bg-primary" />
              </div>
              
              <p className="text-[10px] text-foreground-muted leading-relaxed uppercase tracking-widest font-bold">
                Alpha Nodes detect regional price imbalances and suggest direct buybacks to protect farmer margins.
              </p>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center py-4 border-b border-white/5 group/line">
                  <span className="mono text-[10px] text-white/40 uppercase group-hover/line:text-white transition-colors">Trade Alpha</span>
                  <span className="mono text-[10px] text-primary font-black">+4.22%</span>
                </div>
                <div className="flex justify-between items-center py-4 border-b border-white/5 group/line">
                  <span className="mono text-[10px] text-white/40 uppercase group-hover/line:text-white transition-colors">Buy Status</span>
                  <span className="bg-green/10 text-green px-2 py-1 text-[9px] font-black uppercase tracking-widest">Active</span>
                </div>
                <div className="flex justify-between items-center py-4">
                  <span className="mono text-[10px] text-white/40 uppercase">Fleet Unit</span>
                  <span className="mono text-[10px] text-white">TN-04-A-1024</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

