import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/src/lib/LanguageContext';
import { useNavigate } from 'react-router-dom';
import { auth } from '@/src/lib/firebase';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';

export const AuthFlow = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleGoogleSignIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      navigate('/configure');
    } catch (error) {
      console.error("Sign in failed", error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="w-full max-w-sm">
        <div className="mb-12 text-center">
          <h1 className="display text-4xl font-black text-white tracking-tighter uppercase mb-2">
            DIGITAL<span className="text-primary"> ORCHARD</span>
          </h1>
          <p className="text-foreground-muted uppercase tracking-[3px] text-[10px] font-bold">
            Identity Authorization
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <Button 
            onClick={handleGoogleSignIn} 
            variant="outline" 
            className="w-full h-16 border-white/10 flex items-center justify-center gap-4 hover:border-primary group transition-all"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
            <span className="mono text-xs font-black uppercase tracking-widest group-hover:text-primary">Sign in with Google</span>
          </Button>

          <div className="relative py-4">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/5"></div></div>
            <div className="relative flex justify-center text-[8px] uppercase tracking-[4px] font-bold text-white/20">
              <span className="bg-background px-4">Secure Gateway</span>
            </div>
          </div>

          <p className="text-[10px] text-center text-foreground-muted leading-relaxed uppercase tracking-wider px-4">
            By Authorizing, you agree to the Digital Orchard Architecture and data integrity protocols.
          </p>
        </motion.div>
      </div>
    </div>
  );
};
