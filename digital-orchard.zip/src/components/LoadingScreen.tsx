import React from 'react';
import { motion } from 'framer-motion';

export const LoadingScreen = () => {
  // Generate high-density lines for a true 'scanning' effect
  const horizontalLines = Array.from({ length: 40 });
  const verticalLines = Array.from({ length: 20 });

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1, ease: "easeInOut" }}
      className="fixed inset-0 z-[999] bg-[#050505] flex flex-col items-center justify-center noise-bg overflow-hidden cursor-none"
    >
      {/* Background Decor */}
      <div className="absolute inset-0 os-grid opacity-20 pointer-events-none" />
      
      {/* Horizontal Line System */}
      <div className="absolute inset-0 flex flex-col justify-between py-0 pointer-events-none opacity-20">
        {horizontalLines.map((_, i) => (
          <motion.div
            key={`h-${i}`}
            initial={{ scaleX: 0, originX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{
              duration: 2,
              delay: i * 0.03,
              ease: "circOut",
              repeat: Infinity,
              repeatType: "reverse",
              repeatDelay: 0.2
            }}
            className="w-full h-px bg-primary"
          />
        ))}
      </div>

      {/* Vertical Line System */}
      <div className="absolute inset-0 flex justify-between px-0 pointer-events-none opacity-10">
        {verticalLines.map((_, i) => (
          <motion.div
            key={`v-${i}`}
            initial={{ scaleY: 0, originY: 0 }}
            animate={{ scaleY: 1 }}
            transition={{
              duration: 3,
              delay: i * 0.1,
              ease: "circOut",
              repeat: Infinity,
              repeatType: "reverse",
              repeatDelay: 0.5
            }}
            className="h-full w-px bg-primary"
          />
        ))}
      </div>

      {/* Binary Data Stream - Margins */}
      <div className="absolute left-4 top-0 bottom-0 flex flex-col justify-around opacity-10 pointer-events-none overflow-hidden">
        {Array.from({ length: 15 }).map((_, i) => (
          <motion.p 
            key={`b-l-${i}`}
            animate={{ opacity: [0.1, 1, 0.1] }}
            transition={{ duration: 2, delay: i * 0.2, repeat: Infinity }}
            className="mono text-[8px] text-primary writing-mode-vertical tracking-widest"
          >
            {Math.random().toString(2).slice(2, 10)}
          </motion.p>
        ))}
      </div>

      <div className="absolute right-4 top-0 bottom-0 flex flex-col justify-around opacity-10 pointer-events-none overflow-hidden">
        {Array.from({ length: 15 }).map((_, i) => (
          <motion.p 
            key={`b-r-${i}`}
            animate={{ opacity: [0.1, 1, 0.1] }}
            transition={{ duration: 2, delay: i * 0.3, repeat: Infinity }}
            className="mono text-[8px] text-primary writing-mode-vertical tracking-widest"
          >
            {Math.random().toString(16).slice(2, 6).toUpperCase()}
          </motion.p>
        ))}
      </div>

      {/* High-Contrast Scanning Line */}
      <motion.div 
        animate={{ y: ["-10%", "110%"] }}
        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        className="absolute top-0 left-0 w-full h-[50px] bg-gradient-to-b from-transparent via-primary/30 to-transparent pointer-events-none z-20 border-b border-primary/50 shadow-[0_10px_40px_-10px_rgba(29,185,84,0.5)]"
      />

      <div className="relative z-30 flex flex-col items-center gap-10">
        <div className="flex flex-col items-center gap-3">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="display text-4xl font-black text-white uppercase tracking-[0.6em] drop-shadow-[0_0_20px_rgba(29,185,84,0.5)]">
              ORCHARD<span className="text-primary">_OS</span>
            </h1>
          </motion.div>
          
          <div className="flex items-center gap-6">
            <div className="h-px w-12 bg-primary/40" />
            <div className="flex flex-col items-center">
              <p className="mono text-[11px] font-bold text-primary uppercase tracking-[0.4em]">
                ESTABLISHING_PROTOCOLS
              </p>
              <div className="flex gap-1 mt-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <motion.div 
                    key={i}
                    animate={{ scale: [1, 1.5, 1], opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1, delay: i * 0.1, repeat: Infinity }}
                    className="w-1 h-1 bg-primary rounded-full"
                  />
                ))}
              </div>
            </div>
            <div className="h-px w-12 bg-primary/40" />
          </div>
        </div>

        {/* Diagnostic Terminal */}
        <div className="flex flex-col items-start gap-1.5 font-mono text-[9px] text-white/40 uppercase tracking-widest bg-black/60 backdrop-blur-xl p-6 border border-white/10 rounded-sm shadow-2xl min-w-[320px]">
          <div className="flex justify-between w-full border-b border-white/5 pb-1 mb-2">
            <span className="text-primary font-black">SYSTEM DIAGNOSTICS</span>
            <span className="text-white/20">V.4.0.1</span>
          </div>
          <div className="flex gap-4"><span>[SYS]</span> <span className="text-primary/80">KERNEL_READY</span></div>
          <div className="flex gap-4"><span>[CPU]</span> <span className="text-primary/80">STABILIZED @ 5.4GHZ</span></div>
          <div className="flex gap-4"><span>[MEM]</span> <span className="text-primary/80">CACHING DATABASE... 40%</span></div>
          <div className="flex gap-4"><span>[NET]</span> <span className="text-primary/80">LATENCY: 4MS (NODE_GREEN)</span></div>
          <motion.div 
            animate={{ opacity: [1, 0.4, 1] }} 
            transition={{ duration: 0.3, repeat: Infinity }}
            className="flex gap-4 mt-2"
          >
            <span className="text-primary animate-pulse">≫</span> <span>ALLOCATING_RESOURCES...</span>
          </motion.div>
        </div>
      </div>

      <div className="absolute bottom-16 flex flex-col items-center gap-2">
        <div className="flex gap-12 mono text-[8px] text-white/30 tracking-[0.3em] uppercase">
          <span>SECURE_SHELL</span>
          <span>FARMER_AUTH</span>
          <span>DIRECT_MARKET</span>
        </div>
      </div>
    </motion.div>
  );
};
